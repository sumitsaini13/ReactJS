// Code Here

import React from 'react';
import ReactDOM from 'react-dom';
import {BlogsComponent} from './BlogsComponent'
import {CustomButtonComponent} from './CustomButton'
import {UsersComponent} from './Users'

//ReactDOM.render(<ButtonListComponent initialcount="10"/>, document.getElementById('content'));
ReactDOM.render(<UsersComponent />, document.getElementById('content'));