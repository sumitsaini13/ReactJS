import React from 'react'

export class CommentsComponent extends React.Component{
    render(){
        return <div>
                    <b> {this.props.firstComment} </b> <br />
                </div>
    }
}