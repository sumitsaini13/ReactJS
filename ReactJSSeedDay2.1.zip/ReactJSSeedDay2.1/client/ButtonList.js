import React from 'react'

export class ButtonListComponent extends React.Component{

constructor(props){
    super(props);
}

// Conversion of virtual DOM to actual DOM
componentWillMount(){
    this.state = {list:[20, 30, 100]}
    console.log('componentWillMount...');
}

// Decides whether the component should be rendered again or not? 
// like in case of a textbox not accepting more than 3 characters however, user is clicking again and again 
shouldComponentUpdate(){
    console.log('shouldComponentUpdate...');
    return true;
}

componentWillUpdate(){
    console.log('componentWillUpdate...');
}

AddButtonListHandler(){
    //this.setState({list:})
    var textData = ReactDOM.FindNode(this.state.inputData).value;
}

render(){
    console.log('render...');
    return          <div>
                        Add Button: <input  type="text"></input>
                        <button onClick={this.AddButtonListHandler.bind(this)} value="Add!"></button>
                    </div>
}

// Called after Conversion of virtual DOM to actual DOM
componentDidMount(){
    console.log('componentDidMount...');
}

}