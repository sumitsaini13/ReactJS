import React from 'react';
import {CommentsComponent} from './comments'
import {Comment} from './comment'

export class BlogsComponent extends React.Component{
    
    constructor(){
        super();
        this.Comment = new Comment('I am the comment'); 
    }
        render(){
            return <div>
                        <h1>Hello Component !</h1>
                        <CommentsComponent firstComment={this.Comment.Description} />
                    </div>
                }
}