import React from 'react'

export class UsersComponent extends React.Component{

constructor(props){
 super(props);
 this.state = {users: []};
}

    render(){

        var usersToBeCreated = this.state.users.map((user,index) => {
                return <li key={index}>{user.login}</li>
        });

        return <div>
                <ul>
                        {usersToBeCreated}
                </ul>
                </div>
    }

    componentDidMount(){
        $.get('https://api.github.com/users', (response) => {
            //console.log(respone);
            this.setState({users:response});
        } )
    }
}