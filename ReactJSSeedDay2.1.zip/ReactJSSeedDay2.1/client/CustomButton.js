import React from 'react';

export class CustomButtonComponent extends React.Component{

    constructor(props){
        super(props);
        this.state = {count:+(this.props.initialcount)};
    }

    OnClickHandler(){
        this.setState({count: this.state.count + 1});
    }

    render(){
        return <button onClick={this.OnClickHandler.bind(this)}>{this.state.count}</button>
    }
}