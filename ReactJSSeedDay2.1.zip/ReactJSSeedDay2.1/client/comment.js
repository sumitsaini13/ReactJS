export class Comment{
    constructor(desc){
        this.Description = desc;
    }
}